'use strict';
/* =====================================================================
   Fa1Blox 5.0 extension module: safety, friends, private servers, cloud,
   vehicles, tools, new modes, water/ladders, day-night/weather, studio,
   badges, season pass, world records, events, music, juice.
   ===================================================================== */
(function(){
/* ---------------- styles & DOM ---------------- */
document.head.insertAdjacentHTML('beforeend',`<style>
#hLb{pointer-events:auto!important}
#hLb div[data-n]{cursor:pointer;border-radius:6px}
#hLb div[data-n]:active{background:rgba(255,255,255,.12)}
#hAct{right:max(120px,calc(env(safe-area-inset-right) + 112px));bottom:max(34px,calc(env(safe-area-inset-bottom) + 24px));width:64px;height:64px;border-radius:50%;font-size:26px;background:rgba(255,77,109,.3);border-color:rgba(255,77,109,.8)}
#hExit{right:max(120px,calc(env(safe-area-inset-right) + 112px));bottom:max(110px,calc(env(safe-area-inset-bottom) + 100px));padding:0 12px;height:42px;font-size:13px}
.xcard{background:var(--card);border-radius:16px;padding:12px 14px;margin-bottom:12px}
.xcard h4{margin:0 0 8px;font:800 15px var(--display)}
.xrow{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.xrow input{flex:1;min-width:120px;background:var(--navy2);border:2px solid var(--line);border-radius:12px;color:var(--ink);font:700 14px var(--body);padding:9px 11px;-webkit-user-select:text;user-select:text}
.xmuted{color:var(--muted);font-size:12.5px;margin:6px 0 0}
.flist>div{display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid var(--line)}
.flist>div:last-child{border:0}
.flist b{flex:1;min-width:0;font:800 14px var(--display);overflow:hidden;text-overflow:ellipsis}
.flist .btn{padding:6px 10px;font-size:12px}
.badges{display:grid;grid-template-columns:repeat(auto-fill,minmax(92px,1fr));gap:8px}
.badges div{background:var(--card);border-radius:14px;padding:10px 6px;text-align:center;font-size:11.5px;color:var(--muted)}
.badges div i{display:block;font-size:28px;font-style:normal;filter:grayscale(1);opacity:.35}
.badges div.on{color:var(--ink);box-shadow:inset 0 0 0 2px var(--sun)}
.badges div.on i{filter:none;opacity:1}
.badges div b{display:block;color:inherit;font:800 12px var(--display);margin:4px 0 2px}
.tiers{display:grid;grid-template-columns:repeat(auto-fill,minmax(104px,1fr));gap:8px}
.tier{background:var(--card);border:2px solid var(--line);border-radius:14px;padding:8px 6px;text-align:center;display:flex;flex-direction:column;align-items:center;gap:4px;font-size:12px}
.tier .lv{font:800 11px var(--display);color:var(--muted)}
.tier .ic{font-size:30px;min-height:64px;display:grid;place-items:center}
.tier .ic img{width:64px;height:64px}
.tier.got{border-color:var(--mint)}
.tier.lock{opacity:.5}
.tier .btn{padding:5px 9px;font-size:11.5px}
.comm{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
.comm button{background:var(--card);border:0;border-radius:14px;padding:12px;text-align:left}
.comm button b{display:block;font:800 14px var(--display)}
.comm button span{color:var(--muted);font-size:12px}
#evBanner{display:flex;align-items:center;gap:12px;border-radius:16px;padding:12px 14px;margin-bottom:14px;font-weight:600}
#evBanner p{margin:0;flex:1}
#evBanner b{font-family:var(--display);display:block;font-size:16px}
#pubBox{position:fixed;inset:0;z-index:32;background:rgba(5,7,25,.7);display:grid;place-items:center;padding:0 20px}
.nav button b{font-size:20px}
</style>`);
const $=s=>document.querySelector(s);
const el=(tag,cls,html)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(html!==undefined)e.innerHTML=html;return e;};

/* nav: pass page */
const passBtn=el('button','', '<b>🎫</b>Пропуск');passBtn.dataset.p='pPass';
document.querySelector('.nav').insertBefore(passBtn,document.querySelector('.nav button[data-p=pProfile]'));
passBtn.onclick=()=>{sfx.click();showPage('pPass');};
const pPass=el('div','page');pPass.id='pPass';pPass.hidden=true;document.querySelector('#menu').insertBefore(pPass,document.querySelector('.nav'));
/* games page sections */
const ev=el('div');ev.id='evBanner';ev.hidden=true;$('#pGames').insertBefore(ev,$('#pGames').firstChild);
const priv=el('div','xcard');priv.id='privCard';$('#pGames').insertBefore(priv,$('#gameTabs').previousElementSibling);
const comm=el('div');comm.id='commSec';$('#pGames').insertBefore(comm,$('#netNote'));
/* profile sections */
const prof=$('#pProfile');
const accCard=el('div','xcard');accCard.id='accCard';prof.insertBefore(accCard,prof.querySelector('.lvl'));
const extProf=el('div');extProf.id='extProf';prof.appendChild(extProf);
/* HUD */
const hAct=el('button','hb','⚔️');hAct.id='hAct';hAct.hidden=true;hAct.setAttribute('aria-label','Действие');$('#hud').appendChild(hAct);
const hExit=el('button','hb','🚪 Выйти');hExit.id='hExit';hExit.hidden=true;$('#hud').appendChild(hExit);
const pub=el('div','');pub.id='pubBox';pub.hidden=true;pub.innerHTML='<div class="dlg"><h4>Опубликовать карту</h4><p>Название увидят все игроки</p><div class="xrow" style="margin-bottom:12px"><input id="pubName" maxlength="24" placeholder="Моя крутая карта"></div><div class="acts"><button class="btn sun" id="pubGo">Опубликовать</button><button class="btn" id="pubNo">Отмена</button></div></div>';document.body.appendChild(pub);

/* ---------------- data defaults ---------------- */
DEF_AV.tool='tool_none';if(!S.av.tool)S.av.tool='tool_none';
S.blocked=S.blocked||[];S.friends=S.friends||[];S.badges=S.badges||{};S.pass=S.pass||{xp:0,claimed:[]};S.tycoon=S.tycoon||{n:0,up:[]};if(S.music===undefined)S.music=true;
if(!S.owned.includes('tool_none'))S.owned.push('tool_none');
TYPE_NAMES.tool='Инструменты';
ITEMS.push(
  {id:'tool_none',t:'tool',n:'Пустые руки',p:0,ic:'✋'},
  {id:'tool_flash',t:'tool',n:'Фонарик',p:120,ic:'🔦',d:'светит в темноте'},
  {id:'tool_rod',t:'tool',n:'Удочка',p:150,ic:'🎣',d:'лови рыбу у воды'},
  {id:'tool_sword',t:'tool',n:'Меч',p:250,ic:'⚔️',d:'побеждает зомби'},
  {id:'tool_blaster',t:'tool',n:'Пенный бластер',p:320,ic:'🔫',d:'стреляет пеной'},
  {id:'hat_goldcap',t:'hat',n:'Золотая кепка',p:0,ic:'🧢',pass:5},
  {id:'shirt_s1',t:'shirt',n:'Футболка Сезон 1',p:0,ic:'🎽',pass:10},
  {id:'trail_s1',t:'trail',n:'След Сезона',p:0,ic:'✨',pass:15},
  {id:'back_darkwings',t:'back',n:'Тёмные крылья',p:0,ic:'🦇',pass:20},
  {id:'pet_golddragon',t:'pet',n:'Золотой дракон',p:0,ic:'🐲',pass:25}
);

/* ---------------- events ---------------- */
const now=new Date(),M=now.getMonth()+1,D=now.getDate();
const EVENT=(M===10&&D>=20)||(M===11&&D<=5)?'halloween':(M===12&&D>=20)||(M===1&&D<=10)?'newyear':null;
if(EVENT==='halloween')ITEMS.forEach(i=>{if(['hat_pumpkin','skin_pumpkin','skin_vampire','face_skull'].includes(i.id)){i.p0=i.p0||i.p;i.p=Math.round(i.p0/2);i.d='−50% Хэллоуин!';}});
if(EVENT==='newyear')ITEMS.forEach(i=>{if(['hat_santa','hat_antlers','hat_beanie'].includes(i.id)){i.p0=i.p0||i.p;i.p=Math.round(i.p0/2);i.d='−50% Новый год!';}});
function birthday(){if(M===10&&D===30&&S.bday!==now.getFullYear()){S.bday=now.getFullYear();addBux(500);save();setTimeout(()=>{dialog('🎂 День рождения Fa1Blox!','Сегодня игре исполняется год (ну, почти)!\nДержи подарок: +500 Fa1Bux',[['Спасибо!','','sun']]);for(let i=0;i<5;i++)setTimeout(sfx.win,i*300);},3600);}}
birthday();

/* ---------------- chat safety ---------------- */
const STRONG=['хуй','хуе','хуё','хуя','пизд','пидор','пидр','гандон','шлюх','залуп','ебан','ебат','ебал','ебл','заеб','выеб','уеб','долбоеб','мудак','мудил','fuck','shit','bitch','cunt','nigg','whore'];
const EXACT=['бля','блять','блядь','бляха','сука','суки','суке','суку','сукой','dick','fag','ass'];
EXT.filter=t=>{let s=String(t).slice(0,80);
  s=s.replace(/(\+?\d[\d\s\-()]{6,}\d)/g,'***').replace(/(https?:\/\/|www\.)\S+/gi,'***').replace(/@[a-z0-9_]{3,}/gi,'***');
  return s.split(/(\s+)/).map(w=>{const l=w.toLowerCase().replace(/ё/g,'е').replace(/[^a-zа-я]/g,'');if(!l)return w;
    return STRONG.some(b=>l.includes(b.replace(/ё/g,'е')))||EXACT.includes(l)?'*'.repeat(Math.max(3,Math.min(8,w.length))):w;}).join('');};
EXT.isBlocked=uid=>S.blocked.some(b=>b.uid===uid);
$('#hLb').addEventListener('click',e=>{const row=e.target.closest('[data-n]');if(!row||!W)return;const c=W.chars.find(c=>c.remote&&c.name===row.dataset.n);if(!c){toast(row.dataset.n===S.name?'Это ты 🙂':'Это бот');return;}playerMenu(c);});
function playerMenu(c){
  paused=false;const fr=S.friends.some(f=>f.uid===c.uid);
  dialog(c.name,'Что сделать с игроком?',[
    [fr?'✓ Уже в друзьях':'🤝 Добавить в друзья',()=>{if(!fr){S.friends.push({uid:c.uid,n:c.name});save();toast(c.name+' теперь в друзьях');badge('friend');}}, 'mint'],
    ['🚫 Заблокировать',()=>{S.blocked.push({uid:c.uid,n:c.name});save();netRemove(c.uid);toast(c.name+' заблокирован');}],
    ['⚠️ Пожаловаться',()=>reportMenu(c),'red'],['Отмена']]);
}
function reportMenu(c){
  const send=m=>{netSend('POST','reports',{by:NET.uid,on:c.uid,n:c.name,m,room:NET.room||'',t:{'.sv':'timestamp'}});toast('Жалоба отправлена. Спасибо!');};
  dialog('Жалоба на '+c.name,'Выбери причину',[['Мат или оскорбления',()=>send('abuse')],['Читы',()=>send('cheat')],['Спам',()=>send('spam')],['Неприличный ник',()=>send('name')],['Отмена']]);
}

/* ---------------- private servers + presence ---------------- */
EXT.suffix='';
function code5(){const a='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let s='';for(let i=0;i<5;i++)s+=a[Math.floor(Math.random()*a.length)];return s;}
function renderPriv(){
  const on=NET.state==='ok';
  priv.innerHTML=`<h4>🔒 Приватный сервер</h4>`+(!on?`<p class="xmuted">Нужен онлайн. Создай код и дай его друзьям — вы окажетесь на одном сервере.</p>`:
    EXT.suffix?`<div class="xrow"><b style="font:800 16px var(--display)">Код: <span style="color:var(--sun)">${EXT.suffix.slice(1)}</span></b><button class="btn" id="pvCopy">Скопировать</button><button class="btn red" id="pvLeave">Выйти в общий</button></div><p class="xmuted">Все карты, которые ты запускаешь, теперь только для тех, у кого этот код.</p>`:
    `<div class="xrow"><button class="btn sun" id="pvNew">Создать</button><input id="pvCode" maxlength="5" placeholder="Код друга"><button class="btn" id="pvJoin">Войти</button></div>`);
  const q=s=>priv.querySelector(s);
  if(q('#pvNew'))q('#pvNew').onclick=()=>{EXT.suffix='_'+code5();sfx.win();renderPriv();};
  if(q('#pvJoin'))q('#pvJoin').onclick=()=>{const v=(q('#pvCode').value||'').toUpperCase().replace(/[^A-Z0-9]/g,'');if(v.length!==5){toast('Код из 5 символов');return;}EXT.suffix='_'+v;sfx.cp();renderPriv();};
  if(q('#pvLeave'))q('#pvLeave').onclick=()=>{EXT.suffix='';renderPriv();};
  if(q('#pvCopy'))q('#pvCopy').onclick=()=>{try{navigator.clipboard.writeText(EXT.suffix.slice(1)).then(()=>toast('Код скопирован'),()=>toast('Код: '+EXT.suffix.slice(1)));}catch(_){toast('Код: '+EXT.suffix.slice(1));}};
}
function presence(){if(NET.state!=='ok'||!NET.uid)return;netSend('PUT','presence/'+NET.uid,{n:S.name,r:NET.room||'',t:{'.sv':'timestamp'}});}
setInterval(presence,40000);
async function friendStatus(f){if(NET.state!=='ok')return null;try{const r=await fetch(netUrl('presence/'+f.uid));if(!r.ok)return null;return await r.json();}catch(_){return null;}}
function joinRoom(room){const g=GAMES.find(g=>room===g.id||room.indexOf(g.id+'_')===0);if(!g){toast('Друг на карте игроков');return;}EXT.suffix=room.slice(g.id.length);startGame(g);}

/* ---------------- account & cloud save ---------------- */
const AUTHX=p=>DEV?DEV.auth+'/'+p:'https://identitytoolkit.googleapis.com/v1/accounts:'+p+'?key='+FB.apiKey;
const ERR={EMAIL_EXISTS:'Такая почта уже занята — нажми «Войти»',INVALID_PASSWORD:'Неверный пароль',EMAIL_NOT_FOUND:'Аккаунт не найден',INVALID_LOGIN_CREDENTIALS:'Неверная почта или пароль',INVALID_EMAIL:'Неправильная почта',OPERATION_NOT_ALLOWED:'Вход по почте выключен в Firebase',CREDENTIAL_TOO_OLD_LOGIN_AGAIN:'Перезайди в игру и попробуй снова'};
const errMsg=m=>{for(const k in ERR)if(String(m).indexOf(k)===0)return ERR[k];if(/WEAK_PASSWORD/.test(m))return 'Пароль минимум 6 символов';return 'Ошибка: '+m;};
async function cloudSave(){if(!S.email||NET.state!=='ok')return;const o={...S};delete o.fbRefresh;delete o.fbDb;delete o.giftShow;await netSend('PUT','saves/'+NET.uid,JSON.stringify(o));}
let csT=0;const _save=save;save=function(){_save();if(S.email){clearTimeout(csT);csT=setTimeout(cloudSave,12000);}};
async function linkAcc(email,pw){await netAuth();const r=await fetch(AUTHX('update'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({idToken:NET.token,email,password:pw,returnSecureToken:true})});
  const j=await r.json();if(!r.ok)throw new Error(j.error&&j.error.message||r.status);NET.token=j.idToken;if(j.refreshToken)S.fbRefresh=j.refreshToken;NET.exp=Date.now()+(+j.expiresIn||3600)*1000;S.email=email;_save();await cloudSave();}
async function loginAcc(email,pw){const r=await fetch(AUTHX('signInWithPassword'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password:pw,returnSecureToken:true})});
  const j=await r.json();if(!r.ok)throw new Error(j.error&&j.error.message||r.status);
  NET.token=j.idToken;NET.uid=j.localId;NET.exp=Date.now()+(+j.expiresIn)*1000;S.fbRefresh=j.refreshToken;S.email=email;
  if(!NET.db)await netFindDb();
  const d=await (await fetch(netUrl('saves/'+NET.uid))).json();
  if(d&&typeof d==='string'){const o=JSON.parse(d);const keep={fbRefresh:S.fbRefresh,fbDb:S.fbDb,email};S=Object.assign(S,o,keep);}
  _save();location.reload();}
function renderAcc(){
  if(S.email){accCard.innerHTML=`<h4>☁️ Аккаунт</h4><div class="xrow"><span style="flex:1;min-width:0;overflow-wrap:anywhere">${esc(S.email)}</span><button class="btn mint" id="acSave">Сохранить сейчас</button><button class="btn" id="acOut">Выйти</button></div><p class="xmuted">Прогресс, Fa1Bux и вещи сохраняются в облако и не пропадут при переустановке.</p>`;
    accCard.querySelector('#acSave').onclick=()=>{cloudSave().then(()=>toast('Сохранено в облако ☁️'));};
    accCard.querySelector('#acOut').onclick=()=>dialog('Выйти из аккаунта?','На этом телефоне останется гостевой профиль.',[['Выйти',()=>{delete S.email;delete S.fbRefresh;_save();location.reload();},'red'],['Отмена']]);}
  else{accCard.innerHTML=`<h4>☁️ Аккаунт</h4><div class="xrow"><input id="acMail" type="email" placeholder="Почта" autocomplete="email"><input id="acPw" type="password" placeholder="Пароль (6+ символов)" autocomplete="current-password"></div><div class="xrow" style="margin-top:8px"><button class="btn sun" id="acNew">Создать аккаунт</button><button class="btn" id="acIn">Войти</button></div><p class="xmuted">Сейчас ты гость: прогресс хранится только на этом телефоне. С аккаунтом он будет в облаке.</p>`;
    const go=async(fn)=>{const e=accCard.querySelector('#acMail').value.trim(),p=accCard.querySelector('#acPw').value;if(!e||!p){toast('Введи почту и пароль');return;}if(NET.state!=='ok'){toast('Нужен интернет');return;}try{await fn(e,p);toast('Готово!');renderAcc();}catch(er){toast(errMsg(er.message));}};
    accCard.querySelector('#acNew').onclick=()=>go(linkAcc);accCard.querySelector('#acIn').onclick=()=>go(loginAcc);}
}

/* ---------------- vehicles ---------------- */
EXT.VEH={car:{sp:2.5,n:'Машина'},skate:{sp:1.6,n:'Скейт'},hover:{sp:2.1,n:'Ховерборд'}};
function vehMesh(k,col){
  const g=new THREE.Group(),L=c=>new THREE.MeshLambertMaterial({color:c}),Ph=c=>new THREE.MeshPhongMaterial({color:c,shininess:90,specular:'#ffffff'});
  const add=(geo,m,x,y,z)=>{const o=new THREE.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=true;g.add(o);return o;};
  if(k==='car'){add(rbox(1.9,.6,3,.18),Ph(col||'#ff4d6d'),0,.55,0);add(rbox(1.6,.55,1.5,.15),new THREE.MeshPhongMaterial({color:'#bfe6ff',transparent:true,opacity:.55,shininess:100}),0,1.05,-.25);
    for(const a of[-1,1])for(const b of[-1,1]){const w=add(new THREE.CylinderGeometry(.34,.34,.26,16),L('#1a1a1f'),a*.95,.34,b*1);w.rotation.z=Math.PI/2;}
    add(rbox(.5,.15,.05,.03),new THREE.MeshBasicMaterial({color:'#fff6c0'}),-.6,.6,1.52);add(rbox(.5,.15,.05,.03),new THREE.MeshBasicMaterial({color:'#fff6c0'}),.6,.6,1.52);g.position.y=-.05;}
  else if(k==='skate'){add(rbox(.75,.08,1.7,.04),L(col||'#ff8a3d'),0,.14,0);for(const b of[-1,1])for(const a of[-1,1]){const w=add(new THREE.CylinderGeometry(.08,.08,.08,10),L('#f0f0f0'),a*.25,.05,b*.55);w.rotation.z=Math.PI/2;}}
  else{add(rbox(.9,.12,1.8,.06),Ph(col||'#1de9ff'),0,.32,0);const gl=add(rbox(.7,.04,1.5,.02),new THREE.MeshBasicMaterial({color:'#7ff9ff'}),0,.25,0);g.userData.glow=gl;}
  return g;
}
function setVeh(c,k){if(c.vmesh){c.g.remove(c.vmesh);c.vmesh=null;}c.veh=k||null;if(k){c.vmesh=vehMesh(k);c.g.add(c.vmesh);}}
EXT.touch=(b,ch)=>{if(b.type!=='veh'||!EXT.VEH[b.data]||ch!==player||player.veh||player.vehCD>0)return;setVeh(player,b.data);hExit.hidden=false;sfx.cp();toast(EXT.VEH[b.data].n+'! Жми «Выйти», чтобы слезть');badge('drive');};
hExit.onclick=()=>{if(!player)return;setVeh(player,null);player.vehCD=2;hExit.hidden=true;sfx.click();};
function vehPad(x,z,k){const col={car:'#ff4d6d',skate:'#ff8a3d',hover:'#1de9ff'}[k];box(x,.12,z,2.8,.24,2.8,col,'veh',{data:k,solid:false,glow:true});sign({car:'🚗 МАШИНА',skate:'🛹 СКЕЙТ',hover:'🛸 ХОВЕР'}[k],x,2.6,z,Math.PI,'#0e1230','#ffffff',3.2);}

/* ---------------- tools ---------------- */
function toolMesh(id){
  const g=new THREE.Group(),L=c=>new THREE.MeshLambertMaterial({color:c}),Ph=c=>new THREE.MeshPhongMaterial({color:c,shininess:100,specular:'#ffffff'});
  const add=(geo,m,x,y,z)=>{const o=new THREE.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=true;g.add(o);return o;};
  if(id==='tool_sword'){add(rbox(.12,1.2,.04,.03),Ph('#e8ecf4'),0,.75,0);add(rbox(.42,.08,.1,.03),Ph('#ffcc00'),0,.12,0);add(rbox(.09,.28,.09,.03),L('#6b4a2b'),0,-.05,0);}
  else if(id==='tool_blaster'){add(rbox(.26,.6,.34,.06),L('#ff8a3d'),0,.25,0);add(new THREE.CylinderGeometry(.08,.08,.5,12),L('#3aa0ff'),0,.7,0);add(rbox(.2,.14,.3,.04),L('#ffe066'),0,.15,-.12);}
  else if(id==='tool_rod'){const r=add(new THREE.CylinderGeometry(.03,.045,2.2,8),L('#8d5a3b'),0,1.05,0);add(new THREE.CylinderGeometry(.1,.1,.08,12),L('#c9ccd6'),.08,.2,0).rotation.z=Math.PI/2;}
  else if(id==='tool_flash'){add(new THREE.CylinderGeometry(.08,.07,.45,12),L('#2b2d36'),0,.2,0);add(new THREE.CylinderGeometry(.11,.09,.1,12),new THREE.MeshBasicMaterial({color:'#fff6c0'}),0,.46,0);}
  g.rotation.x=Math.PI/2;return g;
}
function attachTool(c,id){
  const P=c.body.userData.P;c.toolBody=c.body;if(c.toolMesh&&c.toolMesh.parent)c.toolMesh.parent.remove(c.toolMesh);c.toolMesh=null;c.toolId=id;
  if(id&&id!=='tool_none'){const arm=P.armR,m=arm.children[0];const h=m.geometry.parameters?m.geometry.parameters.height:.9;c.toolMesh=toolMesh(id);c.toolMesh.position.set(0,-(h||.9)+.1,.08);arm.add(c.toolMesh);}
}
const projs=[];
let fishing=null,flash=null;
function useTool(){
  if(!player||player.dead||paused)return;const id=S.av.tool;
  const fx=Math.sin(player.yaw),fz=Math.cos(player.yaw);
  if(id==='tool_sword'){if(player.swing>0)return;player.swing=.35;tone(900,.12,'sawtooth',.03,-600);
    setTimeout(()=>{if(!W)return;for(const c of W.chars){if(c===player||c.dead||c.remote)continue;const dx=c.pos.x-player.pos.x,dz=c.pos.z-player.pos.z,d=Math.hypot(dx,dz);if(d<2.9&&(dx*fx+dz*fz)/Math.max(d,.01)>.3&&Math.abs(c.pos.y-player.pos.y)<2){hit(c,dx/d,dz/d);}}},110);}
  else if(id==='tool_blaster'){const m=new THREE.Mesh(new THREE.SphereGeometry(.18,10,8),new THREE.MeshLambertMaterial({color:'#7ff9ff',emissive:'#1a6a7a'}));m.position.set(player.pos.x+fx*.9,player.pos.y+1.5,player.pos.z+fz*.9);W.root.add(m);
    projs.push({m,v:new V3(fx*30,0,fz*30),life:1.1});tone(1400,.1,'square',.03,-900);}
  else if(id==='tool_rod'){if(fishing)return;if(!nearWater()){toast('Подойди к воде 🌊');return;}
    const b=new THREE.Mesh(new THREE.SphereGeometry(.15,10,8),new THREE.MeshLambertMaterial({color:'#ff4d6d'}));const wy=EXT.waterTop(player)||0;b.position.set(player.pos.x+fx*4,wy,player.pos.z+fz*4);W.root.add(b);
    fishing={b,t:1.8+Math.random()*3};tone(500,.2,'triangle',.04,-200);toast('Ждём поклёвку…');}
  else if(id==='tool_flash'){if(flash){player.g.remove(flash);flash=null;toast('Фонарик выключен');return;}
    flash=new THREE.SpotLight(0xfff6d0,2.2,34,.55,.45,1);flash.position.set(0,2.2,.2);const t=new THREE.Object3D();t.position.set(0,1.2,8);player.g.add(t);flash.target=t;player.g.add(flash);toast('Фонарик включён 🔦');}
}
function hit(c,dx,dz){
  for(let i=0;i<8;i++)particle(c.pos.x,c.pos.y+1.2,c.pos.z,'#ffe066',1);
  if(c.zombie){c.die();badge('zombie');addBux(2);}else{c.vel.x+=dx*14;c.vel.z+=dz*14;c.vel.y=8;c.ground=false;}
}
hAct.addEventListener('pointerdown',e=>{e.preventDefault();useTool();});
function nearWater(){if(!W||!W.waters||player.inW)return false;return W.waters.some(w=>player.pos.x>w.min.x-4&&player.pos.x<w.max.x+4&&player.pos.z>w.min.z-4&&player.pos.z<w.max.z+4&&player.pos.y>=w.max.y-1&&player.pos.y<w.max.y+4);}
EXT.waterTop=(ch)=>{if(!W.waters)return null;const w=W.waters.find(w=>ch.pos.x>w.min.x-6&&ch.pos.x<w.max.x+6&&ch.pos.z>w.min.z-6&&ch.pos.z<w.max.z+6);return w?w.max.y:null;};
EXT.inWater=(ch)=>{if(!W||!W.waters)return false;const y=ch.pos.y+.7;return W.waters.some(w=>ch.pos.x>w.min.x&&ch.pos.x<w.max.x&&ch.pos.z>w.min.z&&ch.pos.z<w.max.z&&y>w.min.y&&y<w.max.y);};
EXT.splash=(ch)=>{for(let i=0;i<10;i++)particle(ch.pos.x,ch.pos.y+.6,ch.pos.z,'#9fd8ff',2);if(ch===player){tone(300,.25,'sine',.05,-150);badge('swim');}};
const FISH=[['Старый ботинок 🥾',0,12],['Карась 🐟',3,35],['Окунь 🐠',5,25],['Щука 🐡',10,15],['Сом 🐋',18,8],['Золотая рыбка ✨',40,5]];

/* ---------------- per-frame (game) ---------------- */
let wx=null,envCfg=null,dayBase=null,flashT=0,stepT=0,secT=0;
EXT.tick=(dt)=>{
  if(!player)return;
  // tool visuals/arm
  if(player.toolId!==S.av.tool||player.toolBody!==player.body)attachTool(player,S.av.tool);
  hAct.hidden=!S.av.tool||S.av.tool==='tool_none'||!!G.tap;hAct.textContent={tool_sword:'⚔️',tool_blaster:'💥',tool_rod:'🎣',tool_flash:'🔦'}[S.av.tool]||'✋';
  hExit.hidden=!player.veh;
  // projectiles
  for(let i=projs.length-1;i>=0;i--){const p=projs[i];p.life-=dt;p.m.position.addScaledVector(p.v,dt);let gone=p.life<=0;
    for(const c of W.chars){if(c===player||c.dead||c.remote)continue;if(c.pos.distanceTo(new V3(p.m.position.x,c.pos.y+1.2,p.m.position.z))<1.1&&Math.abs(p.m.position.y-c.pos.y-1.2)<1.4){hit(c,p.v.x/30,p.v.z/30);gone=true;break;}}
    if(gone){W.root.remove(p.m);projs.splice(i,1);}}
  // fishing
  if(fishing){fishing.t-=dt;fishing.b.position.y+=Math.sin(W.t*8)*.004;if(fishing.t<=0){const tot=FISH.reduce((a,f)=>a+f[2],0);let r=Math.random()*tot,f=FISH[0];for(const x of FISH){if(r<x[2]){f=x;break;}r-=x[2];}
    W.root.remove(fishing.b);fishing=null;if(f[1])addBux(f[1]);sfx.coin();toast('Поймал: '+f[0]+(f[1]?' +'+f[1]:''));badge('fish');passXP(3);}}
  // footsteps
  if(player.ground&&player.move>.4&&!player.veh){stepT-=dt;if(stepT<0){stepT=.3;tone(90+Math.random()*30,.04,'triangle',.02);}}
  // day/night + weather
  envTick(dt);
  // badges & pass time
  secT+=dt;if(secT>10){secT=0;passXP(2);checkBadges();}
};
EXT.charTick=(c,dt)=>{
  if(c.ground&&c.wasG===false&&(c.prevVy||0)<-10){c.sq=.18;for(let i=0;i<6;i++)particle(c.pos.x+(Math.random()-.5),c.pos.y+.1,c.pos.z+(Math.random()-.5),'#d8d0c0',0);if(c===player)tone(70,.08,'sine',.06);}
  c.wasG=c.ground;c.prevVy=c.vel.y;
  if(c.sq>0){c.sq-=dt;const k=Math.max(0,c.sq/.18);c.body.scale.set(1+.12*k,1-.15*k,1+.12*k);}else if(c.body.scale.y!==1)c.body.scale.set(1,1,1);
  if(c.ground&&c.move>.7&&!c.veh&&!c.inW){c.dustT=(c.dustT||0)-dt;if(c.dustT<0){c.dustT=.2;particle(c.pos.x,c.pos.y+.08,c.pos.z,'#cfc8b8',0);}}
  if(c.av.body==='body_slim')c.body.rotation.z=c.move>.1?Math.sin(c.t*10)*.04*c.move:0;
  if(c.vehCD>0)c.vehCD-=dt;
  if(c.vmesh&&c.vmesh.userData.glow)c.vmesh.userData.glow.material.color.setHSL(.5,1,.55+Math.sin(c.t*6)*.15);
  if(c.veh==='car'&&c.vmesh)c.vmesh.children.forEach((w,i)=>{if(i>=2&&i<6)w.rotation.x+=c.move*dt*20;});
  const P=c.body.userData.P;
  if(c.swing>0){c.swing-=dt;const k=1-c.swing/.35;P.armR.rotation.x=-2.6+k*3.2;P.armR.rotation.z=0;}
  else if(c.toolMesh&&!c.veh){P.armR.rotation.x=lerp(P.armR.rotation.x,-.75,Math.min(1,dt*10));}
};
EXT.remoteTick=(c,st,dt)=>{
  if((st.vh||null)!==(c.veh||null))setVeh(c,st.vh||null);
  const tl=st.tl||'tool_none';if(c.toolId!==tl||c.toolBody!==c.body)attachTool(c,tl);
  if(c.toolMesh)c.body.userData.P.armR.rotation.x=-.75;
};
EXT.onMeet=()=>badge('meet');

/* ---------------- day / night / weather ---------------- */
const HANG={city:1,beach:1,school:1,snow:1,pirate:1,koth:1,soccer:1,tycoon:1};
function envSetup(g){
  envCfg=HANG[g.id]?{cycle:true}:null;dayBase=scene.background?scene.background.clone():null;wx=null;
  sun.intensity=.85;
  if(!envCfg)return;
  const snow=g.id==='snow'||EVENT==='newyear';
  const geo=new THREE.BufferGeometry(),N=snow?900:700,pos=new Float32Array(N*(snow?3:6));
  for(let i=0;i<N;i++){const x=(Math.random()-.5)*50,y=Math.random()*30,z=(Math.random()-.5)*50;if(snow){pos.set([x,y,z],i*3);}else pos.set([x,y,z,x,y-.7,z],i*6);}
  geo.setAttribute('position',new THREE.BufferAttribute(pos,3));
  const obj=snow?new THREE.Points(geo,new THREE.PointsMaterial({color:'#ffffff',size:.22,transparent:true,opacity:.9})):new THREE.LineSegments(geo,new THREE.LineBasicMaterial({color:'#a8c8ff',transparent:true,opacity:.55}));
  obj.frustumCulled=false;obj.visible=false;W.root.add(obj);wx={obj,snow,N,kind:'clear'};
}
const NIGHT=new THREE.Color('#0b1030'),tmpC=new THREE.Color();
function envTick(dt){
  if(!envCfg||!dayBase)return;
  const T=(srvNow()/1000%300)/300,day=clamp(.5+Math.cos((T-.25)*6.283)*.9,0,1);
  tmpC.copy(NIGHT).lerp(dayBase,day);scene.background.copy(tmpC);if(scene.fog)scene.fog.color.copy(tmpC);
  sun.intensity=.15+.7*day;hemi.intensity=.3+.45*day;
  if(wx){const w=Math.floor(srvNow()/90000),r=rng(w)();const kind=wx.snow?'snow':r<.6?'clear':r<.85?'rain':'storm';
    if(kind!==wx.kind){wx.kind=kind;wx.obj.visible=kind!=='clear';if(kind!=='clear')toast(kind==='snow'?'❄️ Идёт снег':kind==='rain'?'🌧️ Начался дождь':'⛈️ Гроза!');}
    if(wx.obj.visible){const p=wx.obj.geometry.attributes.position,a=p.array,sp=wx.snow?3:28,cx=camera.position.x,cz=camera.position.z,cy=camera.position.y;
      const st=wx.snow?3:6;for(let i=0;i<wx.N;i++){const o=i*st;let y=a[o+1]-sp*dt;let x=a[o],z=a[o+2];if(wx.snow){x+=Math.sin(W.t+i)*dt*.6;}
        if(y<cy-12||Math.abs(x-cx)>25||Math.abs(z-cz)>25){y=cy+14+Math.random()*4;x=cx+(Math.random()-.5)*50;z=cz+(Math.random()-.5)*50;}
        a[o]=x;a[o+1]=y;a[o+2]=z;if(!wx.snow){a[o+3]=x;a[o+4]=y-.7;a[o+5]=z;}}p.needsUpdate=true;}
    if(wx.kind==='storm'){flashT-=dt;if(flashT<0){flashT=6+Math.random()*10;hemi.intensity=2.2;setTimeout(()=>{hemi.intensity=.5;},120);setTimeout(()=>tone(55,1.2,'sawtooth',.06,-20),600);}}
  }
}

/* ---------------- music ---------------- */
let musT=null;
function hash(s){let h=7;for(const c of s)h=(h*31+c.charCodeAt(0))|0;return Math.abs(h);}
function musicStart(id){
  musicStop();if(!S.music)return;audio();if(!AC)return;
  const R=rng(hash(id)),minor=['halloween','cave','zombie','volcano','neon','lava','moon'].includes(id);
  const scale=minor?[0,3,5,7,10]:[0,2,4,7,9],root=[220,196,233,175,262][Math.floor(R()*5)];
  const prog=minor?[0,8,3,10]:[0,5,9,7];const mel=[];for(let i=0;i<64;i++)mel.push(R()<.55?scale[Math.floor(R()*5)]+(R()<.25?12:0):null);
  let step=0;const bpm=minor?120:132,ms=60000/bpm/4;
  musT=setInterval(()=>{if(paused||state!=='play'||!S.music)return;const bar=Math.floor(step/16)%4,beat=step%16,cr=root*Math.pow(2,prog[bar]/12);
    if(beat%4===0)tone(cr/2,.25,'triangle',.03);if(beat%8===4)tone(cr*Math.pow(2,(minor?3:4)/12)/2,.18,'triangle',.018);
    const n=mel[step%64];if(n!==null&&beat%2===0)tone(cr*Math.pow(2,n/12),.14,'square',.012);
    if(beat%4===2)tone(2400,.02,'square',.006);step++;},ms);
}
function musicStop(){if(musT)clearInterval(musT);musT=null;}

/* ---------------- badges ---------------- */
const BADGES=[['first','Первые шаги','Сыграй первую игру','🎮'],['obby','Паркурщик','Пройди любое обби','🏃'],['volcano','Огнеупорный','Пройди «Вулкан»','🔥'],['tower','Покоритель башен','Пройди башню','🗼'],
  ['win10','Чемпион','10 побед','🏆'],['rich','Богач','Заработай 5000 Fa1Bux','💰'],['shop','Модник','Купи 10 вещей','👕'],['friend','Друг','Добавь друга','🤝'],['meet','Не один','Встреть игрока онлайн','🌐'],
  ['drive','Водитель','Прокатись на транспорте','🚗'],['fish','Рыбак','Поймай рыбу','🎣'],['zombie','Охотник','Победи зомби','⚔️'],['map','Архитектор','Опубликуй карту','🏗️'],['tycoon','Бизнесмен','5 улучшений в тайкуне','🏭'],
  ['goal','Футболист','Забей гол','⚽'],['koth','Царь горы','Победи в «Царе горы»','👑'],['cats','Кошатник','Найди всех котиков','🐱'],['pumpkin','Хэллоуин 2026','Собери все тыквы','🎃'],['swim','Пловец','Поплавай в море','🏊'],['pass10','Сезонщик','10 уровень пропуска','🎫']];
function badge(id){if(S.badges[id])return;const b=BADGES.find(b=>b[0]===id);if(!b)return;S.badges[id]=Date.now();addBux(50);passXP(20);save();setTimeout(()=>{sfx.win();toast('🏅 '+b[1]+' · +50 Fa1Bux');},300);}
EXT.badge=badge;
function checkBadges(){if(S.wins>=10)badge('win10');if(S.coins>=5000)badge('rich');if(ITEMS.filter(i=>i.p>0&&S.owned.includes(i.id)).length>=10)badge('shop');if(passLevel()>=10)badge('pass10');}

/* ---------------- season pass ---------------- */
const PASS_N=30,PASS_XP=120;
const passLevel=()=>Math.min(PASS_N,Math.floor(S.pass.xp/PASS_XP));
function passReward(i){const it=ITEMS.find(x=>x.pass===i);if(it)return{item:it};if(i===PASS_N)return{bux:1000};return{bux:20+i*5};}
function passXP(n){const before=passLevel();S.pass.xp+=n;if(passLevel()>before&&state==='play')toast('🎫 Уровень пропуска '+passLevel()+'!');}
function renderPass(){
  const lv=passLevel(),cur=S.pass.xp-lv*PASS_XP;
  pPass.innerHTML=`<h2>🎫 Сезон 1: Блочный старт</h2><div class="lvl"><b style="font:800 16px var(--display)">Уровень ${lv} / ${PASS_N}</b><div class="bar"><i style="width:${lv>=PASS_N?100:cur/PASS_XP*100}%"></i></div><div style="color:var(--muted);font-size:12px;margin-top:6px">${lv>=PASS_N?'Сезон пройден! 🎉':cur+' / '+PASS_XP+' опыта · опыт даётся за игру, финиши, победы и достижения'}</div></div><div class="tiers" id="tiers"></div>`;
  const t=pPass.querySelector('#tiers');
  for(let i=1;i<=PASS_N;i++){const r=passReward(i),got=S.pass.claimed.includes(i),can=lv>=i&&!got;const d=el('div','tier'+(got?' got':lv<i?' lock':''));
    d.innerHTML=`<span class="lv">Ур. ${i}</span><div class="ic"${r.item?` data-th="${r.item.id}"`:''}>${r.item?r.item.ic:'💰'}</div><span>${r.item?r.item.n:'+'+r.bux+' Fa1Bux'}</span>`;
    const b=el('button','btn'+(can?' sun':''),got?'✓':can?'Забрать':'🔒');b.disabled=!can;b.onclick=()=>{S.pass.claimed.push(i);if(r.item){if(!S.owned.includes(r.item.id))S.owned.push(r.item.id);toast('Получено: '+r.item.n+'! Надень в «Аватаре»');}else addBux(r.bux);save();sfx.win();renderPass();};d.appendChild(b);t.appendChild(d);}
  queueThumbs(t);
}
const _buy=buy;buy=function(it){if(it.pass){toast('🎫 Награда за '+it.pass+' уровень пропуска');return;}_buy(it);};

/* ---------------- world records ---------------- */
EXT.lastLb=null;
async function lbSubmit(key,time){if(NET.state!=='ok')return;try{const r=await fetch(netUrl('lb/'+key+'/'+NET.uid));const o=r.ok?await r.json():null;if(!o||time<o.t)await netSend('PUT','lb/'+key+'/'+NET.uid,{n:S.name,t:+time.toFixed(2)});}catch(_){}}
async function showLb(key,title){
  if(NET.state!=='ok'){toast('Нужен онлайн');return;}
  try{const r=await fetch(NET.db+'/lb/'+key+'.json?orderBy=%22t%22&limitToFirst=10&auth='+encodeURIComponent(NET.token));const d=await r.json()||{};
    const list=Object.entries(d).map(([k,v])=>[k,v]).filter(a=>a[1]&&typeof a[1].t==='number').sort((a,b)=>a[1].t-b[1].t).slice(0,10);
    const txt=list.length?list.map(([k,v],i)=>`${['🥇','🥈','🥉'][i]||(i+1)+'.'} ${String(v.n).slice(0,16)} — ${fmtT(v.t)}${k===NET.uid?'  ← ты':''}`).join('\n'):'Пока никто не прошёл. Будь первым!';
    dialog('🏆 '+(title||'Топ мира'),txt,[['Закрыть','','sun']]);}catch(_){toast('Не удалось загрузить рекорды');}
}
const _finish=finish;finish=function(title,time,key,reward){EXT.lastLb=key;lbSubmit(key,time);passXP(40);
  if(CATMAP[key]==='parkour')badge('obby');if(key==='volcano')badge('volcano');if(key==='tower'||key==='icetower')badge('tower');if(key==='halloween')badge('pumpkin');if(key==='hide')badge('cats');
  _finish(title,time,key,reward);};
result=function(title,text){paused=true;const acts=[['Ещё раз',()=>startGame(W.game),'sun'],['В меню',leaveGame]];const k=EXT.lastLb;
  if(k&&NET.state==='ok')acts.splice(1,0,['🏆 Топ мира',()=>{showLb(k,(GAMES.find(g=>g.id===k)||{n:'Топ мира'}).n);}]);EXT.lastLb=null;passXP(15);dialog(title,text,acts,leaveGame);};

/* ---------------- start / leave wrappers ---------------- */
const _start=startGame;startGame=function(g){fishing=null;flash=null;projs.length=0;hExit.hidden=true;_start(g);envSetup(g);musicStart(g.id);badge('first');presence();
  if(EXT.suffix)logMsg('Fa1Blox','🔒 Приватный сервер: '+EXT.suffix.slice(1),false,true);};
const _leave=leaveGame;leaveGame=function(){musicStop();envCfg=null;sun.intensity=.85;hemi.intensity=.75;_leave();presence();};

/* ---------------- map upgrades (water, ladders, vehicles, events) ---------------- */
const wrap=(id,fn)=>{const g=GAMES.find(g=>g.id===id);if(!g)return;const orig=g.build;g.build=function(){orig();W.waters=W.waters||[];fn();};};
const ladder=(x,z,h,axis,col)=>box(x,h/2,z,axis==='x'?.3:1.3,h,axis==='x'?1.3:.3,col||'#c9ccd6','ladder');
wrap('beach',()=>{W.waters.push({min:new V3(-70,-3.3,19.5),max:new V3(70,-.3,86)});vehPad(-12,-40,'car');vehPad(-6,-40,'skate');vehPad(0,-46,'hover');ladder(-30,-16.2,3.2,'z','#ffffff');});
wrap('pirate',()=>{W.waters.push({min:new V3(-120,-4.3,-120),max:new V3(120,-.45,120)});ladder(-47.25,-2,13,'x','#6b4a2b');});
wrap('city',()=>{vehPad(-8,-18,'car');vehPad(-3,-18,'skate');vehPad(2,-18,'hover');vehPad(7,-18,'car');
  const R=rng(5);[...W.boxes].forEach(b=>{if(b.type!=='solid'||!b.mesh.material.map||b.max.y-b.min.y<9||R()>.4)return;const h=b.max.y;ladder(b.max.x+.15,(b.min.z+b.max.z)/2,h,'x','#d0d4dc');});
  if(EVENT==='halloween')for(let i=0;i<10;i++){const a=i/10*6.283;box(Math.cos(a)*9,.55,Math.sin(a)*9,.9,.8,.9,'#ff8a1d','solid',{glow:true});}
  if(EVENT==='newyear'){box(0,1,-30,1,2,1,'#6b4a2b');[[5,2],[4,3.3],[3,4.5],[2,5.6]].forEach(([w,y])=>box(0,y+.5,-30,w,1.2,w,'#1f8a4f'));}});
wrap('school',()=>{ladder(0,29.45,8.4,'z','#9aa0ad');vehPad(-20,-25,'skate');});
wrap('snow',()=>{vehPad(-5,-20,'skate');vehPad(5,-20,'hover');});
wrap('halloween',()=>{ladder(0,35.45,15.6,'z','#5a4a5a');});

/* ---------------- new modes ---------------- */
function dynSign(x,y,z,ry,w){const c=document.createElement('canvas');c.width=512;c.height=128;const t=new THREE.CanvasTexture(c);const m=new THREE.Mesh(new THREE.PlaneGeometry(w||6,(w||6)/4),new THREE.MeshBasicMaterial({map:t,side:THREE.DoubleSide}));m.position.set(x,y,z);m.rotation.y=ry||0;W.root.add(m);
  return(text,bg,fg)=>{const g=c.getContext('2d');g.fillStyle=bg||'#0e1230';g.fillRect(0,0,512,128);g.fillStyle=fg||'#ffcc00';g.font='800 54px Rubik,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText(text,256,66);t.needsUpdate=true;};}

function mapKoth(){
  sky('#ffcf8a','#ffe8c8',60,220);W.voidY=-20;plat(0,0,0,74,74,'#c9a26b','solid',{grid:true});
  const cols=['#ff5d8f','#ffcc00','#3ee6a8','#3aa0ff','#b07bff','#ff8a3d'];
  for(let i=0;i<6;i++){const sz=28-i*4.4;box(0,i*1.15+.575,0,sz,1.15,sz,cols[i]);}
  const top=6*1.15;const ring=new THREE.Mesh(new THREE.TorusGeometry(2.6,.12,8,32),new THREE.MeshBasicMaterial({color:'#ffe066'}));ring.rotation.x=Math.PI/2;ring.position.y=top+.15;W.root.add(ring);
  for(let i=0;i<4;i++){const a=i*1.5708+.785;box(Math.cos(a)*18,.2,Math.sin(a)*18,2,.4,2,'','bounce');}
  for(let i=0;i<3;i++){const w=28-(i+1)*4.4;mover(box(0,(i+1)*1.15+.5,0,w,.5,.6,'','kill'),'z',w/2-1,.9+i*.3,i*2);}
  W.spawn=[0,.1,-26];W.camYaw=Math.PI;
  spawnBots(5,[0,.1,40,0],61);
  let tl=120,over=false,acc=0;W.score=0;
  const onTop=c=>Math.abs(c.pos.x)<2.6&&Math.abs(c.pos.z)<2.6&&c.pos.y>=top-.1&&!c.dead;
  G={update:dt=>{if(over)return;tl-=dt;acc+=dt;ring.rotation.z+=dt;
      if(acc>=.5){acc=0;for(const c of W.chars){if(c.remote||!onTop(c))continue;if(c===player){W.score++;}else c.score++;}}
      if(tl<=0){over=true;const all=W.chars.map(c=>[c,c===player?W.score:c.score]).sort((a,b)=>b[1]-a[1]);const place=all.findIndex(a=>a[0]===player)+1;if(place===1&&all.length>1)badge('koth');
        if(all.length<2)soloEnd('Очков на вершине: '+W.score,Math.floor(W.score/2));else partyEnd(place,'Очков: '+W.score);}},
     botTarget:b=>new V3((Math.random()-.5)*.5,0,(Math.random()-.5)*.5),
     info:()=>`👑 Стой на вершине! · ${W.score} оч. · ⏱ ${fmtT(tl)}`,
     lb:()=>W.chars.map(c=>[c.name,c===player?W.score:c.score]).sort((a,b)=>b[1]-a[1]).slice(0,6)};
}

function mapSoccer(){
  sky('#8fd3ff','#d6f0ff',80,260);W.voidY=-20;plat(0,0,0,90,70,'#3a9a4a','solid',{grid:true});
  const L=30,Wd=18;box(0,.02,0,60,.04,36,'#4cb85c','solid',{deco:true});
  for(const [x,z,w,d] of [[0,0,.2,36],[0,Wd,60,.2],[0,-Wd,60,.2],[L,0,.2,36],[-L,0,.2,36]])box(x,.06,z,w,.04,d,'#ffffff','solid',{deco:true});
  for(const s of[-1,1]){box(s*(L+.5),.75,s*0,.3,1.5,36.6,'#ffffff');box(0,.75,s*(Wd+.5),61,1.5,.3,'#ffffff');}
  // goals (openings in end walls)
  const goal=(s,col)=>{W.boxes=W.boxes.filter(b=>!(Math.abs((b.min.x+b.max.x)/2-s*(L+.5))<.1&&b.max.x-b.min.x<.5));
    box(s*(L+.5),.75,-11,.3,1.5,14,'#ffffff');box(s*(L+.5),.75,11,.3,1.5,14,'#ffffff');
    for(const z of[-4,4])box(s*(L+.2),1.5,z,.25,3,.25,col);box(s*(L+.2),3,0,.25,.25,8.2,col);box(s*(L+2.4),1.5,0,.2,3,8.2,'#e8ecf4');box(s*(L+1.3),3,0,2.2,.15,8.2,'#e8ecf4');
    for(const z of[-4.1,4.1])box(s*(L+1.3),1.5,z,2.2,3,.15,'#e8ecf4');};
  W.root.children.filter(m=>m.isMesh&&Math.abs(m.position.x)===L+.5&&m.scale.x<.5).forEach(m=>W.root.remove(m));
  goal(1,'#ff4d6d');goal(-1,'#3aa0ff');
  const bt=document.createElement('canvas');bt.width=128;bt.height=64;const bx=bt.getContext('2d');bx.fillStyle='#fff';bx.fillRect(0,0,128,64);bx.fillStyle='#111';for(let i=0;i<8;i++){bx.beginPath();bx.arc((i%4)*34+12+(i>3?17:0),i>3?46:16,8,0,6.283);bx.fill();}
  const ball=new THREE.Mesh(new THREE.SphereGeometry(.6,20,14),new THREE.MeshLambertMaterial({map:new THREE.CanvasTexture(bt)}));ball.castShadow=true;W.root.add(ball);
  const bp=new V3(0,.6,0),bv=new V3();
  W.spawn=[-10,.1,0];W.camYaw=-Math.PI/2;
  spawnBots(5,[0,.1,20,0],71);
  const bots=W.chars.filter(c=>c.bot);bots.forEach((b,i)=>{b.team=i<2?'blue':'red';b.av.torso=b.team==='blue'?'#2f6fed':'#d81b3c';b.av.shirt='shirt_jersey';b.rebuild();b.place([b.team==='blue'?-8-i*4:8+i*3,.1,(i%3-1)*6]);});
  player.team='blue';
  let blue=0,red=0,tl=180,over=false,reset=0,kickCD=new Map();
  const resetBall=()=>{bp.set(0,3,0);bv.set(0,0,0);};
  G={update:dt=>{
      if(over)return;tl-=dt;
      if(reset>0){reset-=dt;if(reset<=0)resetBall();}
      bv.y-=22*dt;bp.addScaledVector(bv,dt);
      if(bp.y<.6){bp.y=.6;if(bv.y<-2)bv.y*=-.5;else bv.y=0;bv.x*=Math.pow(.35,dt);bv.z*=Math.pow(.35,dt);}
      if(Math.abs(bp.z)>Wd-.6){bp.z=Math.sign(bp.z)*(Wd-.6);bv.z*=-.7;}
      if(Math.abs(bp.x)>L-.6){if(Math.abs(bp.z)<3.8&&bp.y<2.9){if(Math.abs(bp.x)>L+1&&reset<=0){const sc=bp.x>0?'blue':'red';if(sc==='blue')blue++;else red++;bigText('ГОЛ! '+blue+' : '+red,1.6);sfx.win();
            if(sc===player.team&&lastKick===player)badge('goal');reset=1.5;}if(Math.abs(bp.x)>L+2.2){bp.x=Math.sign(bp.x)*(L+2.2);bv.x*=-.3;}}
        else{bp.x=Math.sign(bp.x)*(L-.6);bv.x*=-.7;}}
      ball.position.copy(bp);ball.rotation.x+=bv.z*dt;ball.rotation.z-=bv.x*dt;
      for(const c of W.chars){if(c.dead||c.remote)continue;const dx=bp.x-c.pos.x,dz=bp.z-c.pos.z,d=Math.hypot(dx,dz);const cd=kickCD.get(c)||0;if(cd>0){kickCD.set(c,cd-dt);continue;}
        if(d<1.25&&bp.y<2.2){const p=c===player?16:11.5;bv.set(dx/d*p,4+Math.random()*2,dz/d*p);kickCD.set(c,.35);lastKick=c;if(c===player)tone(160,.08,'square',.05);}}
      if(tl<=0||blue>=5||red>=5){over=true;const win=blue>red,draw=blue===red;const rw=win?60:draw?30:15;addBux(rw);if(win){S.wins++;quests().wins++;}save();
        setTimeout(()=>{sfx.win();result(win?'🏆 Победа синих!':draw?'Ничья!':'Победили красные',`Счёт ${blue} : ${red}\n+${rw} Fa1Bux`);},800);}
    },
    botTarget:b=>{const gx=b.team==='blue'?L+2:-L-2;const dx=bp.x-gx,dz=bp.z,d=Math.hypot(dx,dz)||1;return new V3(bp.x+dx/d*1.1,0,bp.z+dz/d*1.1);},
    respawnBot:b=>b.place([b.team==='blue'?-10:10,.1,0]),
    info:()=>`⚽ Синие ${blue} : ${red} Красные · ⏱ ${fmtT(tl)} · бей в красные ворота`,
    lb:()=>[['Синие',blue],['Красные',red]]};
  let lastKick=null;
}

function mapHide(){
  sky('#a8e6a1','#e0f5d8',60,200);W.voidY=-20;plat(0,0,0,90,90,'#6cc36c','solid',{grid:true});
  const HX=0,HZ=10,Wd=26,Dp=20,Ht=5,wc='#f0dcc0';plat(HX,.2,HZ,Wd,Dp,'#c8a87a');
  box(HX,Ht/2,HZ+Dp/2,Wd,Ht,.5,wc,'solid',{win:true});for(const s of[-1,1]){box(s*Wd/2,Ht/2,HZ,.5,Ht,Dp,wc,'solid',{win:true});box(s*(Wd/4+1.2),Ht/2,HZ-Dp/2,Wd/2-2.4,Ht,.5,wc,'solid',{win:true});}
  box(HX,Ht-.8,HZ-Dp/2,4.8,1.6,.5,wc);box(0,Ht/2,HZ+2,.4,Ht,Dp/2-2+2,'#e0c8a8');box(-6.5,Ht/2,HZ,13,Ht,.4,'#e0c8a8');box(-3,Ht/2,HZ,.01,.01,.01,'#000');
  box(HX,Ht+.2,HZ,Wd+1,.4,Dp+1,'#b0303a');ladder(Wd/2+.45,HZ+4,Ht+.4,'x','#9aa0ad');
  box(-9,.6,HZ+6,4,.8,2,'#3aa0ff');box(-9,1.1,HZ+7,4,1,.5,'#2f6fed');box(8,.75,HZ+6,3,.1,2,'#c08a4a');box(8,.4,HZ+6,.2,.7,.2,'#8a5a2a');box(-9,.6,HZ-5,3,.8,2.2,'#ff9ad5');box(6,1.2,HZ-6,1.5,2.4,.8,'#8d5a3b');box(9,1,HZ+.5,2,2,.8,'#e8ecf4');
  for(let i=0;i<12;i++){const a=i/12*6.283;box(Math.cos(a)*34,1,Math.sin(a)*34,2.4,2,2.4,'#2f8f3f');}
  for(let i=0;i<6;i++)tree(-30+i*12,-30,1);
  const spots=[[8,0,HZ+6.5],[-9,1,HZ+5.6],[-9,0,HZ-6.5],[6,2.4,HZ-6],[0,Ht+.4,HZ],[Math.cos(.5)*34,2,Math.sin(.5)*34],[Math.cos(3)*34,2,Math.sin(3)*34],[-30,0,-31.5],[30,0,-28],[9,2,HZ+.5]];
  spots.forEach(p=>{const c=coin(p[0],p[1],p[2],{gem:true});W.root.remove(c.m);const m=petMesh('pet_cat');m.position.set(p[0],p[1]+.05,p[2]);W.root.add(m);c.m=m;c.pumpkin=true;});
  W.spawn=[0,.1,-14];
  collectG('🐱','Котики',spots.length,'hide',90,'Все котики найдены!');
}

function mapTycoon(){
  sky('#9fd8ff','#e0f4ff',70,240);W.voidY=-20;plat(0,0,0,80,80,'#7ec850','solid',{grid:true});
  const T=S.tycoon;T.up=T.up||[];plat(0,.2,0,34,26,'#d9dee8');
  const conv=box(1,1,0,26,.6,2.2,'#2b2d36');const ct=document.createElement('canvas');ct.width=64;ct.height=16;const cx=ct.getContext('2d');cx.fillStyle='#2b2d36';cx.fillRect(0,0,64,16);cx.fillStyle='#ffcc00';for(let i=0;i<4;i++)cx.fillRect(i*16,0,6,16);
  const ctex=new THREE.CanvasTexture(ct);ctex.wrapS=ctex.wrapT=THREE.RepeatWrapping;ctex.repeat.set(8,1);conv.mesh.material=new THREE.MeshLambertMaterial({map:ctex});
  box(15,1.6,0,2.4,3.2,3,'#3ee6a8','solid',{glow:true});
  const cash=box(15,.25,5,3,.3,3,'#2fbf71','veh',{data:'cash',solid:false,glow:true});const cashSign=dynSign(15,3.4,5,Math.PI,5);
  const UPS=[];const dropX=[-11,-8,-5,-2,1,4,7,10];
  dropX.forEach((x,i)=>UPS.push({id:'d'+i,n:'Дроппер '+(i+1),p:[0,40,90,160,260,400,580,800][i],x}));
  UPS.push({id:'gold',n:'Золотой дроппер',p:1200,x:-11,gold:true});UPS.push({id:'walls',n:'Стены и окна',p:150});UPS.push({id:'fountain',n:'Фонтан',p:250});UPS.push({id:'tower',n:'Башня-офис',p:600});
  const built=new Set(T.up);
  const drops=[];let bank=W.bank=0;
  const buildUp=u=>{
    if(u.x!==undefined&&!u.gold){box(u.x,3.6,0,1.4,1.2,1.4,'#7b4dff');box(u.x,2.8,0,.7,.6,.7,'#5a3acf');drops.push({x:u.x,v:1,t:Math.random()*2});}
    if(u.gold){box(u.x,4.2,-1.8,1.6,1.4,1.6,'#ffcc00','solid',{glow:true});drops.push({x:u.x,v:5,t:1,z:-1.8,gold:true});}
    if(u.id==='walls'){for(const s of[-1,1]){box(s*17,1.7,0,.5,3,26,'#e8d5b0','solid',{win:true});box(0,1.7,s*13,34,3,.5,'#e8d5b0','solid',{win:true});}W.boxes=W.boxes.filter(b=>!(b.max.z>12.5&&b.min.z<13.5&&Math.abs(b.min.x)<2&&b.max.y<3.5));}
    if(u.id==='fountain'){box(-10,.5,-8,4,.8,4,'#9ad0ff');box(-10,1.5,-8,.6,2,.6,'#e8ecf4');}
    if(u.id==='tower'){box(10,4,-9,6,8,5,'#b0c4de','solid',{win:true});sign('FA1 INC',10,8.8,-11.6,Math.PI,'#0e1230','#ffcc00',5);}
  };
  UPS.forEach(u=>{if(built.has(u.id))buildUp(u);});
  if(!built.has('d0')){built.add('d0');T.up.push('d0');buildUp(UPS[0]);save();}
  const pads=[];
  const refreshPads=()=>{pads.forEach(p=>{W.root.remove(p.b.mesh);W.boxes.splice(W.boxes.indexOf(p.b),1);p.sg.forEach(m=>W.root.remove(m));});pads.length=0;
    UPS.filter(u=>!built.has(u.id)).slice(0,3).forEach((u,i)=>{const x=-8+i*8,z=-9;const b=box(x,.25,z,3.2,.3,3.2,S.bux>=u.p?'#ffcc00':'#9aa0ad','veh',{data:'up',solid:false,glow:true});
      const s1=sign(u.n,x,2.8,z,Math.PI,'#0e1230','#ffffff',4.6),s2=sign(u.p+' F',x,1.9,z,Math.PI,'#0e1230','#ffcc00',3);pads.push({b,u,sg:[s1,s2],x,z});});};
  refreshPads();
  const cubes=[];let buyCD=0,cashCD=0;
  W.spawn=[0,.4,-15];W.camYaw=Math.PI;
  G={update:dt=>{
      ctex.offset.x-=dt*.6;buyCD-=dt;cashCD-=dt;
      for(const d of drops){d.t-=dt;if(d.t<=0){d.t=2;const m=new THREE.Mesh(rbox(.5,.5,.5,.08),new THREE.MeshLambertMaterial({color:d.gold?'#ffcc00':'#ff5d8f',emissive:d.gold?'#4a3600':'#000'}));m.position.set(d.x,2.6,d.z||0);m.castShadow=true;W.root.add(m);cubes.push({m,v:d.v,vy:0});}}
      for(let i=cubes.length-1;i>=0;i--){const c=cubes[i];if(c.m.position.y>1.55){c.vy-=20*dt;c.m.position.y=Math.max(1.55,c.m.position.y+c.vy*dt);if(c.m.position.z!==0)c.m.position.z=lerp(c.m.position.z,0,dt*4);}else c.m.position.x+=dt*3.2;
        if(c.m.position.x>13.5){W.root.remove(c.m);cubes.splice(i,1);bank+=c.v;}}
      if(bank!==W.lastBank){W.lastBank=bank;cashSign('Касса: '+bank+' F','#0e1230','#3ee6a8');}
      const on=(x,z,w)=>player.ground&&Math.abs(player.pos.x-x)<w&&Math.abs(player.pos.z-z)<w;
      if(on(15,5,1.6)&&bank>0&&cashCD<=0){addBux(bank);toast('+'+bank+' Fa1Bux');sfx.coin();bank=0;cashCD=.5;passXP(2);}
      for(const p of pads){if(on(p.x,p.z,1.6)&&buyCD<=0){buyCD=1;if(S.bux<p.u.p){toast('Нужно '+p.u.p+' Fa1Bux');break;}S.bux-=p.u.p;updBux();built.add(p.u.id);T.up.push(p.u.id);save();buildUp(p.u);sfx.win();toast('Куплено: '+p.u.n);if(T.up.length>=6)badge('tycoon');refreshPads();break;}}
    },
    info:()=>`🏭 Fa1 Тайкун · дропперов: ${drops.length} · касса: ${bank} F`,lb:()=>[['Улучшений',T.up.length+'/'+UPS.length]]};
}

/* ---------------- Fa1 Studio (builder upgrade) + community maps ---------------- */
const BT=[['solid','🧱 Блок'],['kill','🔥 Лава'],['bounce','🩷 Батут'],['ice','🧊 Лёд'],['speed','⚡ Ускор.'],['cp','🚩 Чекпоинт'],['finish','🏁 Финиш']];
function placeBlock(list,meshes,a,silent){const [x,y,z,c,t]=a;const type=t||'solid';const b=box(x,y,z,2,2,2,c,type,type==='cp'?{data:0}:{});b.mesh.userData.block=b;b.bc=[x,y,z,c,type];list.push(b);meshes.push(b.mesh);return b;}
function renumberCp(list){let n=0;list.filter(b=>b.type==='cp').sort((a,b)=>(a.bc[2]-b.bc[2])||(a.bc[0]-b.bc[0])).forEach(b=>b.data=++n);return n;}
function mapStudio(){
  sky('#9ad0ff','#dff1ff',90,280);W.voidY=-20;
  const ground=plat(0,0,0,96,96,'#7ee081','solid',{grid:true});W.spawn=[0,.1,6];
  const blocks=[];W.buildMeshes=[ground.mesh];
  const COLS=['#ff4d6d','#ff8a3d','#ffe066','#7ee081','#3aa0ff','#7b4dff','#ffffff','#2b2d36','#8d5a3b'];
  let mode='place',color=COLS[0],btype='solid',test=false;
  (S.build||[]).forEach(a=>placeBlock(blocks,W.buildMeshes,a,true));
  const persist=()=>{S.build=blocks.map(b=>b.bc);save();};
  const del=b=>{W.root.remove(b.mesh);W.boxes.splice(W.boxes.indexOf(b),1);blocks.splice(blocks.indexOf(b),1);W.buildMeshes.splice(W.buildMeshes.indexOf(b.mesh),1);persist();};
  const bar=$('#build');bar.hidden=false;bar.innerHTML='';
  const mk=(html,fn,cls)=>{const b=document.createElement('button');b.innerHTML=html;if(cls)b.className=cls;b.onclick=e=>{e.stopPropagation();sfx.click();fn(b);};bar.appendChild(b);return b;};
  const bTest=mk('▶ Тест',()=>{test=!test;bTest.innerHTML=test?'✏️ Строить':'▶ Тест';W.cpIndex=0;W.cp=null;player.place(W.spawn);renumberCp(blocks);toast(test?'Режим теста: пройди свою карту!':'Режим стройки');});
  const bP=mk('🧱',()=>{mode='place';bP.classList.add('on');bD.classList.remove('on');},'on');const bD=mk('⛏️',()=>{mode='del';bD.classList.add('on');bP.classList.remove('on');});
  const tps=BT.map(([t,n],i)=>mk(n,b=>{btype=t;tps.forEach(x=>x.classList.toggle('on',x===b));},i?'':'on'));
  const sws=COLS.map((c,i)=>{const b=mk('',()=>{color=c;sws.forEach(s=>s.classList.toggle('on',s===b));},'sw'+(i?'':' on'));b.style.background=c;return b;});
  mk('📤 Опубликовать',()=>{if(blocks.length<5){toast('Поставь хотя бы 5 блоков');return;}if(NET.state!=='ok'){toast('Нужен онлайн');return;}if(!blocks.some(b=>b.type==='finish')){toast('Добавь блок 🏁 Финиш');return;}paused=true;$('#pubName').value='';pub.hidden=false;setTimeout(()=>$('#pubName').focus(),50);});
  mk('🗑️',()=>dialog('Снести всю постройку?','Это нельзя отменить.',[['Отмена'],['Снести',()=>{[...blocks].forEach(del);},'red']]));
  $('#pubNo').onclick=()=>{pub.hidden=true;paused=false;};
  $('#pubGo').onclick=async()=>{const n=EXT.filter($('#pubName').value.trim()).slice(0,24);if(n.length<3){toast('Название от 3 символов');return;}pub.hidden=true;paused=false;
    const id=(Date.now().toString(36)+Math.random().toString(36).slice(2,6)).slice(0,12);
    await netSend('PUT','mapsData/'+id,{uid:NET.uid,b:JSON.stringify(blocks.map(b=>b.bc))});
    await netSend('PUT','mapsMeta/'+id,{uid:NET.uid,n,a:S.name,c:blocks.length,t:{'.sv':'timestamp'}});
    commCache=null;commT=0;badge('map');toast('Карта «'+n+'» опубликована! 🌍');};
  const ray=new THREE.Raycaster();const st={done:false};
  G={
    info:()=>test?`▶ Тест · чекпоинт ${W.cpIndex} · ⏱ ${fmtT(W.t)}`:`🛠️ Fa1 Studio · блоков: ${blocks.length}`,
    onTouch:(b)=>{if(!test)return;if(b.type==='cp'&&b.data>W.cpIndex){W.cpIndex=b.data;W.cp=[(b.min.x+b.max.x)/2,b.max.y+.05,(b.min.z+b.max.z)/2];sfx.cp();toast('Чекпоинт '+b.data);}
      if(b.type==='finish'&&!st.done){st.done=true;sfx.win();bigText('Карта пройдена!',1.5);setTimeout(()=>{st.done=false;},2000);}},
    tap:(sx,sy)=>{if(test)return;ray.setFromCamera({x:sx/innerWidth*2-1,y:-(sy/innerHeight)*2+1},camera);
      const hit=ray.intersectObjects(W.buildMeshes,false)[0];if(!hit)return;const blk=hit.object.userData.block;
      if(mode==='del'){if(blk){del(blk);sfx.place();}return;}
      const nn=hit.face.normal.clone().transformDirection(hit.object.matrixWorld);let p;
      if(blk){const c=blk.mesh.position;p=[c.x+Math.round(nn.x)*2,c.y+Math.round(nn.y)*2,c.z+Math.round(nn.z)*2];}else{const q=hit.point;p=[Math.floor(q.x/2)*2+1,1,Math.floor(q.z/2)*2+1];}
      if(p[1]<1||blocks.length>=1500)return;
      if(Math.abs(p[0]-player.pos.x)<1+HW&&Math.abs(p[2]-player.pos.z)<1+HW&&p[1]+1>player.pos.y&&p[1]-1<player.pos.y+H)return toast('Тут стоишь ты');
      if(blocks.some(b=>b.bc[0]===p[0]&&b.bc[1]===p[1]&&b.bc[2]===p[2]))return;
      placeBlock(blocks,W.buildMeshes,[p[0],p[1],p[2],color,btype]);persist();sfx.place();},
    lb:()=>[['Блоков',blocks.length]],
  };
}
function mapCommunity(list,name,mid){
  sky('#9ad0ff','#dff1ff',90,280);W.voidY=-20;plat(0,0,0,96,96,'#7ee081','solid',{grid:true});W.spawn=[0,.1,6];
  const blocks=[],meshes=[];const OKT=BT.map(b=>b[0]);list.slice(0,1500).forEach(a=>{if(!Array.isArray(a)||a.length<4)return;const x=Math.round(+a[0]||0),y=Math.max(1,Math.round(+a[1]||1)),z=Math.round(+a[2]||0);if(Math.abs(x)>200||Math.abs(z)>200||y>200)return;
    const c=/^#[0-9a-f]{6}$/i.test(a[3])?a[3]:'#cccccc',t=OKT.includes(a[4])?a[4]:'solid';placeBlock(blocks,meshes,[x,y,z,c,t]);});
  const total=renumberCp(blocks);const st={done:false};
  G={onTouch:cpTouch('u_'+mid,30,'Карта «'+name+'» пройдена!',st),info:()=>st.done?'🏁 Пройдено!':`🌍 ${name} · чекпоинт ${W.cpIndex}/${total} · ⏱ ${fmtT(W.t)}`,lb:()=>[['Чекпоинт',W.cpIndex+'/'+total]]};
}
let commCache=null,commT=0;
async function loadComm(){if(NET.state!=='ok')return;if(commCache&&Date.now()-commT<60000)return;try{const r=await fetch(NET.db+'/mapsMeta.json?orderBy=%22t%22&limitToLast=24&auth='+encodeURIComponent(NET.token));if(!r.ok)return;const d=await r.json()||{};
  commCache=Object.entries(d).filter(([k,v])=>v&&v.n).sort((a,b)=>(b[1].t||0)-(a[1].t||0));commT=Date.now();renderComm();}catch(_){}}
function renderComm(){
  if(NET.state!=='ok'){comm.innerHTML='';return;}
  comm.innerHTML='<h2 style="margin-top:18px">🌍 Карты игроков</h2>';
  if(!commCache){comm.innerHTML+='<p class="xmuted">Загружаем…</p>';return;}
  if(!commCache.length){comm.innerHTML+='<p class="xmuted">Пока пусто. Построй карту в «Стройке» и нажми «Опубликовать»!</p>';return;}
  const g=el('div','comm');commCache.forEach(([id,m])=>{const b=el('button','',`<b>${esc(String(m.n).slice(0,24))}</b><span>от ${esc(String(m.a||'?').slice(0,16))} · ${m.c||0} блоков</span>`);
    b.onclick=async()=>{try{const r=await fetch(netUrl('mapsData/'+id));const d=await r.json();const list=JSON.parse(d.b||'[]');const gid='u_'+id;if(!ONLINE_MAPS.includes(gid))ONLINE_MAPS.push(gid);
      startGame({id:gid,n:String(m.n).slice(0,24),build:()=>mapCommunity(list,String(m.n).slice(0,24),id)});}catch(_){toast('Не удалось загрузить карту');}};g.appendChild(b);});
  comm.appendChild(g);
}

const _it=itemThumb;itemThumb=function(it){if(it.t==='tool')return null;return _it(it);};
/* ---------------- register new games ---------------- */
GAMES.find(g=>g.id==='build').build=mapStudio;GAMES.find(g=>g.id==='build').n='Fa1 Studio';
GAMES.push(
  {id:'koth',n:'Царь горы',tag:'Новое · Пати',ic:'👑',bg:'linear-gradient(135deg,#ffcc00,#ff5d8f)',build:mapKoth},
  {id:'soccer',n:'Блок-футбол',tag:'Новое · Спорт',ic:'⚽',bg:'linear-gradient(135deg,#2fbf71,#3a9a4a)',build:mapSoccer},
  {id:'hide',n:'Прятки с котиками',tag:'Новое · Поиск',ic:'🐱',bg:'linear-gradient(135deg,#ff9a3d,#ffe066)',build:mapHide},
  {id:'tycoon',n:'Fa1 Тайкун',tag:'Новое · Бизнес',ic:'🏭',bg:'linear-gradient(135deg,#7b4dff,#3ee6a8)',build:mapTycoon});
Object.assign(CATMAP,{koth:'party',soccer:'party',hide:'adv',tycoon:'build'});
['koth','soccer','hide','tycoon'].forEach(id=>{if(!ONLINE_MAPS.includes(id))ONLINE_MAPS.push(id);});
$('#gameList').innerHTML='';

/* ---------------- menu wrappers ---------------- */
function renderEvent(){
  if(!EVENT){ev.hidden=true;return;}ev.hidden=false;
  if(EVENT==='halloween'){ev.style.background='linear-gradient(100deg,#2a0b3e,#ff8a1d)';ev.innerHTML='<p><b>🎃 Хэллоуин-ивент</b>Скидки 50% на тыквенные вещи, тыквы в городе и особняк с призами</p><button class="btn sun" id="evGo">Играть</button>';ev.querySelector('#evGo').onclick=()=>startGame(GAMES.find(g=>g.id==='halloween'));}
  else{ev.style.background='linear-gradient(100deg,#0b3a6a,#d81b3c)';ev.innerHTML='<p><b>🎄 Новогодний ивент</b>Снег на всех тусовках, ёлка в городе и скидки на зимние шапки</p><button class="btn sun" id="evGo">В город</button>';ev.querySelector('#evGo').onclick=()=>startGame(GAMES.find(g=>g.id==='city'));}
}
async function renderExtProf(){
  const fr=S.friends.map((f,i)=>`<div><b>${esc(f.n)}</b><span class="xmuted" data-fs="${i}">…</span><button class="btn" data-fj="${i}" hidden>Присоединиться</button><button class="btn" data-fd="${i}">✕</button></div>`).join('')||'<p class="xmuted">Тапни по нику игрока в списке справа во время игры, чтобы добавить в друзья.</p>';
  const bl=S.blocked.map((f,i)=>`<div><b>${esc(f.n)}</b><button class="btn" data-ub="${i}">Разблокировать</button></div>`).join('');
  extProf.innerHTML=`<h3>Друзья</h3><div class="xcard flist">${fr}</div>`+(bl?`<h3>Заблокированные</h3><div class="xcard flist">${bl}</div>`:'')+
    `<h3>Достижения · ${Object.keys(S.badges).length}/${BADGES.length}</h3><div class="badges">${BADGES.map(b=>`<div class="${S.badges[b[0]]?'on':''}"><i>${b[3]}</i><b>${b[1]}</b>${b[2]}</div>`).join('')}</div>`+
    `<h3>Мировые рекорды</h3><div class="xrow">${GAMES.filter(g=>CATMAP[g.id]==='parkour'||['sky','moon','maze','race','jump','cave','halloween','pirate','hide'].includes(g.id)).map(g=>`<button class="btn" data-lb="${g.id}">${g.ic} ${g.n}</button>`).join('')}</div>`+
    `<h3>Звук</h3><div class="field"><button class="btn" id="musBtn" style="flex:1">Музыка: ${S.music?'включена':'выключена'}</button></div>`;
  extProf.querySelectorAll('[data-fd]').forEach(b=>b.onclick=()=>{S.friends.splice(+b.dataset.fd,1);save();renderExtProf();});
  extProf.querySelectorAll('[data-ub]').forEach(b=>b.onclick=()=>{S.blocked.splice(+b.dataset.ub,1);save();renderExtProf();});
  extProf.querySelectorAll('[data-lb]').forEach(b=>b.onclick=()=>showLb(b.dataset.lb,(GAMES.find(g=>g.id===b.dataset.lb)||{}).n));
  extProf.querySelector('#musBtn').onclick=()=>{S.music=!S.music;save();if(!S.music)musicStop();renderExtProf();};
  for(let i=0;i<S.friends.length;i++){const st=await friendStatus(S.friends[i]);const sp=extProf.querySelector(`[data-fs="${i}"]`),jb=extProf.querySelector(`[data-fj="${i}"]`);if(!sp)continue;
    const on=st&&typeof st.t==='number'&&st.t>srvNow()-90000;sp.textContent=on?(st.r?'🟢 играет':'🟢 в меню'):'⚪ не в сети';if(on&&st.r&&jb){jb.hidden=false;jb.onclick=()=>joinRoom(st.r);}}
}
const _rm=renderMenu;renderMenu=function(){_rm();renderEvent();renderPriv();renderComm();if(curPage==='pPass')renderPass();if(curPage==='pProfile'){renderAcc();renderExtProf();}if(NET.state==='ok')loadComm();};
EXT.anyTick=()=>{};
setInterval(()=>{if(NET.state==='ok')presence();},40000);
setTimeout(()=>{presence();renderMenu();},3000);
renderMenu();
})();
